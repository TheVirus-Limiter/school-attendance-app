import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
export default class AppHeader extends React.Component {
  render() {
    return (
      <View style={styles.textcontainer}>
        <Text style={styles.text}>School Attendance</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  textcontainer: {
    backgroundColor: 'orange',
  },
  text: {
    color: 'white',
    padding: 20,
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
